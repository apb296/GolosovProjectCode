

Sdraw=S;
  Sblockdraw = cell(n-1,1); % ...and then get the blocks of this matrix (see Primiceri)
  ijc = 1;
  for jj=2:n
      Sblockdraw{jj-1} = Sdraw(((jj-1)+(jj-3)*(jj-2)/2):ijc,((jj-1)+(jj-3)*(jj-2)/2):ijc);
      ijc = ijc + jj;
  end
 STrue=1;
 
 Atdraw=alpha;
 AlphaTrue=1;
 
 
%  Sigtdraw=log(sigma_tr.^2);
%  
% %     Draws in Sigtdraw are in logarithmic scale (log-volatilies). Create 
%  %    original standard deviations of the VAR covariance matrix
%     sigtemp = eye(n);
%     sigt = zeros(n*t,n);
%      for i = 1:t
%         for j = 1:n
%           sigtemp(j,j) = exp(0.5*Sigtdraw(j,i));
%         end
%          sigt((i-1)*n+1:i*n,:) = sigtemp;
%      end
% %Omegat=Ht      
%          Ht = zeros(n*t,n);
%     Htsd = zeros(n*t,n);
%     for i = 1:t
%         inva = inv(capAt((i-1)*n+1:i*n,:));
%         stem = sigt((i-1)*n+1:i*n,:);
%         Hsd = inva*stem;
%         Hdraw = Hsd*Hsd';
%         Ht((i-1)*n+1:i*n,:) = Hdraw;  % H(t)
%         Htsd((i-1)*n+1:i*n,:) = Hsd;  % Cholesky of H(t)
%     end
% 
%       SigmaTrue=1;
% 
%       
% 
% Wdraw=W;
% WTrue=1;
% % 
 Btdraw=beta;
BetaTrue=1;

