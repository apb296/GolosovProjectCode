
for irep = 2:nrep + nburn    
    
%% Block 1 : Draw beta, Q
 draw_beta_vec;
%% Block 2 : Draw alpha, S
draw_alpha;
%% Block 3 : Draw sigma, W
draw_sigma;

%% After burn-in draws - Storage and Recursive Means
calc_means;

end

