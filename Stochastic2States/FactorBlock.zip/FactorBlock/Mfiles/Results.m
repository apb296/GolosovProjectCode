%% Results

%% Logistics
%
% Time taken to generate all the results
toc
%%
% Number of draws
irep
%%
% Burn-in
nburn
%%
% Storage Batch size
BatchSize
%%
% Training Sample
tau
%%
%% Priors

% _Beta_
%
B_0_prmean
B_0_prvar
%%
% _ALpha_
%
% A_0 ~ N(A_OLS, 4Var(A_OLS))
A_0_prmean 
A_0_prvar
%%
% _Sigma_
%
% log(sigma^2_0) ~ N(log(sigma^2_OLS),4*I_n)
sigma_prmean 
sigma_prvar 
%%



% _Q_
%
% Q is the covariance of B(t), S is the covariance of A(t) and W is the
% covariance of (log) SIGMA(t)
% Q ~ IW(k2_Q*size(subsample)*Var(B_OLS),size(subsample))
%k_Q 
%Q_prmean 
%Q_prvar 
%%
% _W_
%
% W ~ IW(k2_W*(1+dimension(W))*Var(W_OLS),(1+dimension(W)))
k_W 
W_prmean
W_prvar
%%
% _S_
%
% S ~ IW(k2_S*(1+dimension(S)*Var(A_OLS),(1+dimension(S)))
S_prmean{1}
S_prmean{2}
S_prvar     
k_S
%% The BLOW UP problem
BlowUpS=figure('Name', 'Blow up for S');
plot3(stSdraw(:,1),stSdraw(:,2),stSdraw(:,3))
xlabel(['S_{' AlphaLabels(1,:) '}'])
ylabel(['S_{' AlphaLabels(2,:) '}'])
zlabel(['S_{' AlphaLabels(3,:) '}'])
hold on
grid on
axis square
title('Sdraws')
hold off
%%
BlowUpW=figure('Name', 'Blow up for W');
plot3(stWdraw(:,1),stWdraw(:,2),stWdraw(:,3))
xlabel(['W_{' FactorLabels(1,:) '}'])
ylabel(['W_{' FactorLabels(2,:) '}'])
zlabel(['W_{' FactorLabels(3,:) '}'])

hold on
grid on
axis square
title('Wdraws')
hold off
%% Estimation Details
%%
% <FactorDetails.html>
%

%%
% <BetaDiagnostics.html>
%

%%
% <AlphaDiagnostics.html>
%

%%
% <SigmaDiagnostics.html>
%
