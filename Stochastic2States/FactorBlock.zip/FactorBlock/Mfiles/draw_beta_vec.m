 
    % Draws in Sigtdraw are in logarithmic scale (log-volatilies). Create 
    % original standard deviations of the VAR covariance matrix
    m = n + p*(n^2);
    presn = zeros(K,K);
    xhy= zeros(m,1);

      for i = 1:t
       sigtemp = eye(n);
            for j = 1:n
            sigtemp(j,j) = exp(0.5*Sigtdraw(j,i));
        end
    
       % First create capAt, the lower-triangular matrix A(t) with ones on the
    % main diagonal. This is because the vector Atdraw has a draw of only the
    % non-zero and non-one elements of A(t) only.
        capatemp = eye(n);
        aatemp = Atdraw(:,i);
        ic=1;
        for j = 2:n
            capatemp(j,1:j-1) = aatemp(ic:ic+j-2,1)';
            ic = ic + j - 1;
        end
    
       
    % Create the VAR covariance matrix H(t). It holds that:
    %           A(t) x H(t) x A(t)' = SIGMA(t) x SIGMA(t) '
    
    
    
        
        
        Hsd = inv(capatemp)*sigtemp;
        Omega = Hsd*Hsd';
 x = X((i-1)*n+1:i*n,:)';
    presn = presn + x*inv(Omega)*x';        
        xhy = xhy + x*inv(Omega)*y(:,i);
    end

vbar=inv(presn);
beta_vec_ols=vbar*xhy;
v_beta_vec_ols= vbar;

%incorporating the prior
beta_vec_mean=inv([presn+4*VB_OLS])*(presn*beta_vec_ols+4*VB_OLS*B_OLS);
beta_vec_var=inv([presn+4*VB_OLS]);

Bdraw=mvnrnd(beta_vec_mean,beta_vec_var,1)';
Btdrawc=repmat(Bdraw,1,t);
Btdraw=Btdrawc;

    % or use the code below to check for stationarity
%     %Now check for the polynomial roots to see if explosive
     ctemp1 = zeros(n,n*p);
     counter = [];
     restviol=0;
     for i = 1:t;
         BBtempor = Btdrawc(n+1:end,i);
         BBtempor = reshape(BBtempor,n*p,n)';
         ctemp1 = [BBtempor; eye(n*(p-1)) zeros(n*(p-1),n)];
         if max(abs(eig(ctemp1)))>0.9999;
             restviol=1;
             counter = [counter ; restviol]; %#ok<AGROW>
         end
     end
     %if they have been rejected keep old draw, otherwise accept new draw 
     if sum(counter)==0
         Btdraw = Btdrawc;
        % disp('I found a keeper!');
     end




