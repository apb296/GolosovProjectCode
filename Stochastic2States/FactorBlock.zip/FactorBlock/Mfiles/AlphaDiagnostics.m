


%Create the frames for the figures

PostMeanAlpha=figure('Name', 'Posterior Means');
QuantAlpha=figure('Name', 'Quantiles for Alpha');
RecMeanAlpha=figure('Name', 'Recursive Mean for Alpha');
AutoAlpha=figure('Name', 'Autocorrelation for Alpha Draws');
PostS=figure('Name','Posterior for S');
RecMeanS=figure('Name','Recursive Means for S Draws');
AutoS=figure('Name', 'Autocorrelation for S Draws');


figure(PostMeanAlpha);
plot(xData,[At_postmean./nrep]');
legend(AlphaLabels);
SetDates;
rand_t=floor(rand(3,1)*t)+1;

    sctr=1;
for i=1:numa
    figure(QuantAlpha)
        %sctr=sctr+1;
    subplot(3,1,sctr)
     
    %hist(stAtdraw(:,i,1))
   plot(xData,[quantile(squeeze(stAtdraw(:,i,:)),[.25 .5 .75 ])]')
   SetDates;
   title(['Alpha_{' AlphaLabels(i,:) '}'])
   
   figure(RecMeanAlpha);
    subplot(3,1,sctr)
    plot(squeeze((cumsum(stAtdraw(:,i,rand_t))))./repmat([1:stdraws]',1,length(rand_t)))
    title(['Alpha_{' AlphaLabels(i,:) '}'])

   figure(AutoAlpha)

 for rt=1:length(rand_t)
         subplot(length(rand_t),numa,(length(rand_t)*(i-1)+rt))
     autocorr(stAtdraw(:,i,rand_t(rt)))
   
  title([AlphaLabels(i,:) '_t = ' num2str(rand_t(rt))])
 end

 
 
 sctr=sctr+1;
end

% 
 for i=1:numa
        figure(PostS)
     subplot(numa,1,i)
     hist(stSdraw(:,i,1))
     title(['S_{' AlphaLabels(i,:) '}'] )
      figure(RecMeanS)
     subplot(numa,1,i)
     plot(cumsum(stSdraw(:,i,1))./[1:length(stSdraw)]')
     title(['S_{' AlphaLabels(i,:) '}'] )
    figure(AutoS)
    subplot(numa,1,i)
     autocorr(stSdraw(:,i,1))
     title(['S_{' AlphaLabels(i,:) '}'] )
 end


% 
% 
% 






