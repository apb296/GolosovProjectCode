

Bt_postmean(:,1)./nrep
  
PostBeta=figure('Name','Posteriors for Beta');
  RecMeanBeta=figure('Name','Recursive Means for Beta');
  AutoBeta =    figure('Name','Memory in Beta');
      
for i=1:K
    
  figure(PostBeta)
    subplot(3,4,i)
    hist(stBtdraw(:,i,1))
    title(['B' '_' num2str(i)])
figure(RecMeanBeta)
    subplot(3,4,i)
    plot(cumsum(stBtdraw(:,i,1))./[1:stdraws]')
    title(['B' '_' num2str(i)])
figure(AutoBeta)
    subplot(3,4,i)
    autocorr(stBtdraw(:,i,1))
    title(['B' '_' num2str(i)])
end

