
PostMeanSigma=figure('Name', 'Posterior Means for Log-Volatility');
QuantSigma=figure('Name', 'Quantiles for Log-Volatility Draws');
RecMeanSigma=figure('Name', 'Recursive Mean for Log-Volatility Draws');
AutoSigma=figure('Name', 'Autocorrelation for Log-Volatility Draws');
PostW=figure('Name','Posteriors for W');
RecMeanW=figure('Name','Recursive Mean for W');
AutoW=figure('Name','AutoCorr for W');


figure(PostMeanSigma);

plot(xData,[Sigt_postmean./nrep]');
title('Posterior Means')
legend(FactorLabels);
SetDates;
rand_t=floor(rand(3,1)*t)+1;

    

for i=1:n
    figure(QuantSigma)

    subplot(n,1,i)

    %hist(stSigtdraw(:,i,1))
    plot(xData,[quantile(squeeze(stSigtdraw(:,i,:)),[.25 .5 .75 ])]')
    title(['Log(sigma^2_{'  FactorLabels(i,:) '}' ')'])
    SetDates
    figure(RecMeanSigma);
    subplot(n,1,i)
    plot(squeeze((cumsum(stSigtdraw(:,i,rand_t))))./repmat([1:stdraws]',1,length(rand_t)))
    title(['Log(sigma^2_{'  FactorLabels(i,:) '}' ')'])

    figure(AutoSigma);

 for rt=1:length(rand_t)
         subplot(length(rand_t),numa,(length(rand_t)*(i-1)+rt));
     autocorr(stSigtdraw(:,i,rand_t(rt)));
     title(['Memory for t = ' num2str(rand_t(rt))])
 end
 
end


 for i=1:n
        figure(PostW)
     subplot(n,1,i)
     hist(stWdraw(:,i,1))
     title(['W_{' FactorLabels(i,:) '}'] )
      figure(RecMeanW)
     subplot(n,1,i)
     plot(cumsum(stWdraw(:,i))./[1:length(stWdraw)]')
     title(['W_{' FactorLabels(i,:) '}'] )
    figure(AutoW)
    subplot(n,1,i)
     autocorr(stWdraw(:,i,1))
     title(['W_{' FactorLabels(i,:) '}'] )
 end
% [Bt_postmean(:,1)./nrep beta(:,1)]







