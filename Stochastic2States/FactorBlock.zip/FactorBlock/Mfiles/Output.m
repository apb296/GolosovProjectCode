
BatchNo=2;
tic
DataPath=['C:\MATLAB701\work\Low frequency\3Factor2\Data\Prior1\'];
        filename =[DataPath  'BatchNo' num2str(BatchNo) '.mat'];
        %% Results and diagnostics
opts.outputDir = 'C:\Users\Anmol\Documents\My Dropbox\Project 3rdYearPaper\Results\3Factor2\Prior1\';
ResultsDiagnostics;
%%
% <Results.html>
close all;
toc
clear all
BatchNo=2;
%%
DataPath=['C:\MATLAB701\work\Low frequency\3Factor2\Data\Prior2\'];
        filename =[DataPath  'BatchNo' num2str(BatchNo) '.mat'];
        %% Results and diagnostics
opts.outputDir = 'C:\Users\Anmol\Documents\My Dropbox\Project 3rdYearPaper\Results\3Factor2\Prior2\';
ResultsDiagnostics;
%%
% <Results.html>
close all;
clear all
BatchNo=2;
%%
DataPath=['C:\MATLAB701\work\Low frequency\3Factor2\Data\Prior3\'];
        filename =[DataPath  'BatchNo' num2str(BatchNo) '.mat'];
        %% Results and diagnostics
opts.outputDir = 'C:\Users\Anmol\Documents\My Dropbox\Project 3rdYearPaper\Results\3Factor2\Prior3\';
ResultsDiagnostics;
%%
% <Results.html>
close all;
clear all
BatchNo=2;
%%
DataPath=['C:\MATLAB701\work\Low frequency\3Factor2\Data\Prior4\'];
        filename =[DataPath  'BatchNo' num2str(BatchNo) '.mat'];
        %% Results and diagnostics
opts.outputDir = 'C:\Users\Anmol\Documents\My Dropbox\Project 3rdYearPaper\Results\3Factor2\Prior4\';
ResultsDiagnostics;
%%
% <Results.html>
close all;
clear all