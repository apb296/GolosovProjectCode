
%% loop
for i=1:10

    i
end

    
