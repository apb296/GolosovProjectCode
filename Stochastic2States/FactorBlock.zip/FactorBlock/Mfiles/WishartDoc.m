%% Understanding the Wishart Distribution

%% Introduction
% In statistics, the Wishart distribution is a generalization to multiple
% dimensions of the chi-square distribution. In Bayesian inference, the
% Wishart distribution is of particular importance, as it is the conjugate prior of the inverse of the covariance matrix (the precision matrix) of a multivariate normal distribution
%% Construction and Paramters
% Let X be a n x p random matrix, where each row is a independent draw from
% a p-variate normal distribution with zero mean.
% 
% $$X(i)=(x^1_i,\dots,x^p_i)\sim N(0,V)$$
%
% $$ S = X^{'}X \sim W_p (V,n-p)$$
%  
% Thus S is the sum of products of n p-dimensional multivariate normals. n-p is the degrees of freedom and V is the scale matrix. The mean for S is
% (n-p)V. Also note the following property,
%
% $$S \sim W(V,m) \quad \& \quad C_{q x p} (Rnk=q),$$
%
% $$ CWC^{'} \sim W(CVC^{'}, m)$$
%

%% Inverse Wishart
% _Definition_
%
% $$ B \sim W^{-1} ( V, n-p) if B^{-1} \sim W(V^{-1},n-p)$$
%
% $$ E(B)= \frac{V}{n+p-1}$$
%
% _Conjugation_
%
% Let,
%
% $$\Sigma \sim W^{-1} (V,m)$$
%
% $$X | \Sigma \sim N_n(0,\Sigma)$$
%
% $$\Sigma | X \sim W^{-1} (V+XX^{'}, n+m)$$
%
%% Drawing from the Wishart using Barlett's decomposition
%
% To draw from Wish (V,m) 
% _Barlett's Method_
%
% $$Wish(V,m)=Chol(V)Z(m)Z(m)^{'}Chol(V) \quad Z(m) \sim N(0,I)$$
%
V=magic(2)*magic(2)'
n=150;
irep=2000;
W1mean=zeros*V;
W2mean=zeros*V;
for i=1:irep;
    
W1temp = chol(V)'*randn(size(V,1),n);
W1 = W1temp*W1temp';
W1mean=W1mean+W1;

W2=wishrnd(V,n);
W2mean=W2mean+W2;

end
W1mean=W1mean/irep
W2mean=W2mean/irep
AnaMean=V*n

