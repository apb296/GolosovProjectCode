function [aols,vbar,a0,ssig1,a02mo] = ts_prior(rawdat,tau,n,p)
tau=length(rawdat)-p;
yt = rawdat(p+1:tau+p,:)';

%m is the number of elements in the state vector
m = n + p*(n^2);
Zt=[];
for i = p+1:tau+p
    ztemp = eye(n);
    for j = 1:p;
        xlag = rawdat(i-j,1:n);
        xtemp = zeros(n,n*n);
        for jj = 1:n;
            xtemp(jj,(jj-1)*n+1:jj*n) = xlag;
        end
        ztemp = [ztemp   xtemp];
    end
    Zt = [Zt ; ztemp];
end

vbar = zeros(m,m);
xhy = zeros(m,1);
for i = 1:tau
    zhat1 = Zt((i-1)*n+1:i*n,:);
    vbar = vbar + zhat1'*zhat1;
    xhy = xhy + zhat1'*yt(:,i);
end

vbar = inv(vbar);
aols = vbar*xhy;
%vec(B)

sse2 = zeros(n,n);
for i = 1:tau
    zhat1 = Zt((i-1)*n+1:i*n,:);
    sse2 = sse2 + (yt(:,i) - zhat1*aols)*(yt(:,i) - zhat1*aols)';
end
hbar = sse2./tau;

vbar = zeros(m,m);
for i = 1:tau
    zhat1 = Zt((i-1)*n+1:i*n,:);
    vbar = vbar + zhat1'*inv(hbar)*zhat1;
end
vbar = inv(vbar);
%Cov (Vec(B))

achol = chol(hbar)';
% cholesky of Omega(t)
ssig = zeros(n,n);
for i = 1:n
    ssig(i,i) = achol(i,i); 
    for j = 1:n
        achol(j,i) = achol(j,i)/ssig(i,i);
    end
end
%normalizing cholesky of Omega(t) so that diagonal is unity
achol = inv(achol);
numa = n*(n-1)/2;
a0 = zeros(numa,1);
ic = 1;
for i = 2:n
    for j = 1:i-1
        a0(ic,1) = achol(i,j);
        ic = ic + 1;
    end
end
ssig1 = zeros(n,1);
for i = 1:n
    ssig1(i,1) = log(ssig(i,i)^2);
end

hbar1 = inv(tau*hbar);
hdraw = zeros(n,n);
a02mo = zeros(numa,numa);
a0mean = zeros(numa,1);
for irep = 1:4000
    hdraw = wish(hbar1,tau);
    hdraw = inv(hdraw);
    achol = chol(hdraw)';
    ssig = zeros(n,n);
    for i = 1:n
        ssig(i,i) = achol(i,i); 
        for j = 1:n
            achol(j,i) = achol(j,i)/ssig(i,i);
        end
    end
    achol = inv(achol);
    a0draw = zeros(numa,1);
    ic = 1;
    for i = 2:n
        for j = 1:i-1
            a0draw(ic,1) = achol(i,j);
            ic = ic + 1;
        end
    end
    a02mo = a02mo + a0draw*a0draw';
    a0mean = a0mean + a0draw; 
end




a02mo = a02mo./4000;
a0mean = a0mean./4000;
a02mo = a02mo - a0mean*a0mean';

