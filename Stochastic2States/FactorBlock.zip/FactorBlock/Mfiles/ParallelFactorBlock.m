%This Code implemts a Parallel factor_block estimation
clc
clear all

%matlabpool open local 2;

kGrid=[.01 .1];
%parfor i=1:rows(kGrid)
for i=1:rows(kGrid)
        
    k_S=kGrid(i,1);
        k_W=kGrid(i,2);
        factor_block(k_S,k_W,i);

end



%matlabpool close;