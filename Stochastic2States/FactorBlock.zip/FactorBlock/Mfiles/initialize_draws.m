
 %========= INITIALIZE MATRICES:
% Specify covariance matrices for measurement and state equations
consQ = 0.0001;
consS = 0.001;
consH = 0.01;
consW = 0.001;
Ht = kron(ones(t,1),consH*eye(n));   % Initialize Htdraw, a draw from the VAR covariance matrix
Htchol = kron(ones(t,1),sqrt(consH)*eye(n)); % Cholesky of Htdraw defined above
Qdraw = consQ*eye(K);   % Initialize Qdraw, a draw from the covariance matrix Q
Sdraw = consS*eye(numa);  % Initialize Sdraw, a draw from the covariance matrix S
Wdraw = consW*eye(n);    % Initialize Wdraw, a draw from the covariance matrix W
Btdraw = zeros(K,t);     % Initialize Btdraw, a draw of the mean VAR coefficients, B(t)
Atdraw = zeros(numa,t);  % Initialize Atdraw, a draw of the non 0 or 1 elements of A(t)
Sigtdraw = zeros(n,t);   % Initialize Sigtdraw, a draw of the log-diagonal of SIGMA(t)
sigt = kron(ones(t,1),0.01*eye(n));   % Matrix of the exponent of Sigtdraws (SIGMA(t))
statedraw = 5*ones(t,n);       % initialize the draw of the indicator variable 
                              % (of 7-component mixture of Normals approximation)
Zs = kron(ones(t,1),eye(n));
prw = zeros(numel(q_s),1);

%[B1tdraw,A1tdraw ,S1igtdraw,S1blockdraw,W1draw,Q1draw]=init_garch(y_data,n,p);
%save([DataPath 'GarchEstimates.Mat'],'B1tdraw','A1tdraw' ,'S1igtdraw','S1blockdraw','W1draw','Q1draw');
load([LoadDataPath 'GarchEstimates.Mat']);
 Btdraw=B1tdraw;
 Atdraw=A1tdraw;
 Sigtdraw=S1igtdraw;
 Sblockdraw=S1blockdraw;
 Wdraw=W1draw;
 Qdraw=Q1draw;

%[Btdraw,Atdraw ,Sigtdraw,Sblockdraw,Wdraw,Qdraw]  = init_garch(y_data,n,p);
    % Draws in Sigtdraw are in logarithmic scale (log-volatilies). Create 
    % original standard deviations of the VAR covariance matrix
    sigtemp = eye(n);
    sigt = zeros(n*t,n);
    for i = 1:t
        for j = 1:n
            sigtemp(j,j) = exp(0.5*Sigtdraw(j,i));
        end
        sigt((i-1)*n+1:i*n,:) = sigtemp;
    end
    
    ikc = 1;
        for kk = 2:n
            Sdraw(((kk-1)+(kk-3)*(kk-2)/2):ikc,((kk-1)+(kk-3)*(kk-2)/2):ikc)=Sblockdraw{kk-1};
            ikc = ikc + kk;
        end
