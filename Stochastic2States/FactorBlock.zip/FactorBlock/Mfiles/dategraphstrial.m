clc

plot(xData,y)
startDate = datenum(DateLabels(1));
endDate = datenum(DateLabels(end));
xData = linspace(startDate,endDate,length(y'));
fr=12*4
set(gca,'XTick',xData(1:fr:t))
datetick(gca,'x','yyyy','keepticks')
xticklabel_rotate([],45)
