close all;
clc;
clear all;
n=3;
t=200;
nrep=1000;
y=zeros(n,t);
consW=.001;
k_W=0.01; 
W=consW*eye(n);
sizeW=n;

W_prmean = ((k_W)^2)*(1 + sizeW)*eye(n);
W_prvar = 1 + sizeW;


for i=2:t
y(:,i)=mvnrnd(y(:,i-1),W,1);
end

ydiff=diff(y,1,2);

mean(ydiff')
var(ydiff')
cov(ydiff')
plot(y')



for k=1:nrep
sseA_2=zeros(n,n);
for i = 1:t-1
        sseA_2 = sseA_2 + ydiff(:,i)*ydiff(:,i)';
end
    
    Winv = inv((sseA_2 + W_prmean));
    Winvdraw = wish(Winv,t+W_prvar);
    stWdraw(k,:) = diag(inv(Winvdraw) ); % this is a draw from W
    

end

BlowUpW=figure('Name', 'Blow up for W');
%plot(stWdraw(:,1),stWdraw(:,2))
plot3(stWdraw(:,1),stWdraw(:,2),stWdraw(:,3))
WDiag=diag(W)
hold on
 plot3(WDiag(1),WDiag(2),WDiag(3),'-mo',...
                 'LineWidth',2,...
                 'MarkerEdgeColor','k',...
                 'MarkerFaceColor',[.49 1 .63],...
                 'MarkerSize',12)

% %plot(WDiag(1),WDiag(2),'-mo',...
%                  'LineWidth',2,...
%                  'MarkerEdgeColor','k',...
%                  'MarkerFaceColor',[.49 1 .63],...
%                  'MarkerSize',12)

grid on
axis square
title('Wdraws')
hold off


PostW=figure('Name','Posteriors for W');
RecMeanW=figure('Name','Recursive Mean for W');


 for i=1:n
        figure(PostW)
     subplot(n,1,i)
     hist(stWdraw(:,i,1))
     title(['W_' num2str(i)] )
      figure(RecMeanW)
     subplot(n,1,i)
     plot(cumsum(stWdraw(:,i))./[1:nrep]')
     title(['W_' num2str(i)] )
 end
