
function ResultsDiagnostics(filename)
%%
load(filename);
stdraws=BatchSize;
nrep=BatchNo*KTh*BatchSize;
opts.outputDir=OutputPath; 

publish('FactorDetails.m',opts);
close all;
publish('BetaDiagnostics.m',opts);
close all;
publish('AlphaDiagnostics.m',opts);
close all;
publish('SigmaDiagnostics.m',opts);
close all;

publish('Results.m',opts)
close all;


end
