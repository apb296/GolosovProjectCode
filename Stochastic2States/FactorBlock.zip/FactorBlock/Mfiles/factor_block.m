function factor_block(k_W,k_S,ParNo)
%% Factor Block
%% Description
%%
% This code estimates the of the factor block
% with stochastic volatility using KSC's alogorithm. This code will run on
% simulated data
%
% 
%
% The model is:
%
% $$Y_t = B_{0,t} + B_{1,t} Y_{t-1} + e_t$$
%
% Where 
% 
% $$e_t \sim N(0,\Omega_t)$$
% $$A_t\Omega_tA^{'}_t=\Sigma_t\Sigma^{'}_t$$
% $$vec(B_t)=vec(B_{t-1})+Q\eta^b_t$$
% $$vec(A_t)=vec(A_{t-1})+S\eta^a_t$$
% $$vec(\log(\Sigma^2_t)=vec(\log(\Sigma^2_{t-1})+W \eta^s_t$$
%


%% Load Data
% The following script generates data for a 3 factor model with t=200
% We also rerwite the model in vectorized notation as follows
%
% $$y_t=X^{'}_t vec[C_t' B_t]+A_t^{-1}\Sigma_te_t \quad \&$$
% $$X^{'}_t = I_n kron [1 \quad y^{'}_{t-1}]$$

clc;
load_data;


%% Priors and Hyperparameters
% The choice of priors is motivated by their intuitiveness and convenience
% in the applications. 
% The 50 observations are used to calibrate the prior distributions. 
%%
% For example, the mean and the variance of B_0, A_0 are chosen to be the OLS
% point estimates and four times its variance
%%
% For log Sigma_0 instead, the mean of the distribution is chosen to be the logarithm of the OLS point estimates while the variance covariance matrix is arbitrarily.
%%
% Finally, degrees of freedom and scale matrices are needed for the inverse-Wishart prior distributions of the hyperparameters. The degrees of freedom are set to 4 for W and 2 and 3 for the two blocks of S (basically, one plus the dimension of each matrix).For Q the degrees of freedom are set to 40 (size of the training sample), since a slightly tighter prior seems to be necessary in order to avoid implausible behaviours of the time varying coefficient.
%%
 set_priors;

%% Initialipze the draws
% We run a Multivariate DCC Garch on the entire data to obtain a initial
% estimate for the Omega^T. The initial estimates of A^T and Sigma^T
% is set by obtaining a period by period cholesky decomposition of
% Omega^T. The draw for B_t is initialized at the OLS estimate of beta. 
%%
% Given B^T,A^T,Sigma^T, Q, S, W are drawn accordingly. 
initialize_draws;
%% Gibbs Sampling 
% Set up the sampler. This contains specifications as to the number of
% draws, length of burn-in-sample and number of draws to store.
setup_sampler;


%% Begin Sampling


for irep = 2:nrep + nburn    
%% Block 1 : Draw beta, Q
draw_beta_vec;
%draw_beta;
%% Block 2 : Draw alpha, S
draw_alpha;
%set_trueValues;
%% Block 3 : Draw sigma, W
draw_sigma;

%% reset the control variables to the true values
%set_trueValues;

%% After burn-in draws - Storage and Calculate Means
calc_means;
end



% %% Results and diagnostics

%opts.outputDir = 'C:\Users\Anmol\Documents\My Dropbox\Project 3rdYearPaper\Results\FactorBlockThining\';
ResultsDiagnostics(filename);
% %%
% <Results.html>
close all;

end
