
randn('state',sum(100*clock)); %#ok<*RAND>
%rand('twister',sum(100*clock));
%----------------------------------LOAD DATA----------------------------------------
% Load monthly factor data
%LoadDataPath=['C:\MATLAB701\work\Low' ' frequency\FactorBlockThining\Data\'];
LoadDataPath=['/scratch/apb296/FactorBlock/Data/'];
%SaveDataPath=[[LoadDataPath 'Prior' num2str(ParNo) '\']];
SaveDataPath=[LoadDataPath 'Prior' num2str(ParNo) '/'];
OutputPath='/home/apb296/CodeDir/FactorBlock/Output/';
mkdir(OutputPath);
mkdir(SaveDataPath);

   % Load monthly factor data



% [X_real, X_real_headers] = xlsread([DataPath 'macro_data3.xls'], 'real');
% [X_credit, X_credit_headers] = xlsread([DataPath 'macro_data3.xls'], 'credit');
% [X_prices, X_prices_headers] = xlsread([DataPath 'macro_data3.xls'], 'prices');
% [X_code, X_code_headers] = xlsread([DataPath 'macro_data3.xls'], 'CODE_DESC');
load([LoadDataPath 'FactorData.mat']);
load([LoadDataPath 'DateLabels.mat']);
[Loadings_real,Factors_real ,Eigen_real] = princomp(X_real);
[Loadings_credit,Factors_credit ,Eigen_credit] = princomp(X_credit);
[Loadings_prices,Factors_prices ,Eigen_prices] = princomp(X_prices);
FactorLabels=char('Real', 'Credit', 'Prices');
AlphaLabels=char('Real/Credit','Real/Prices','Credit/Prices');
y_data=[Factors_real(:,1) Factors_credit(:,1) Factors_prices(:,1)];
%y_data=y_data_tr';

Y=y_data;

 % Number of observations and dimension of X and Y

t=size(Y,1); % t is the time-series observations of Y
n=size(Y,2); % n is the dimensionality of Y

% Number of factors & lags:
tau = 50; % tau is the size of the training sample
p = 1; % p is number of lags in the VAR part
numa = n*(n-1)/2; % Number of lower triangular elements of A_t (other than 0's and 1's)


% ===================================| VAR EQUATION |==============================
% Following Primeceri, we rewrite the model for y_t in vectorized notation
%  y(t)=X'(t)vec[C' B]+inv(L(t))Sigma(t)e(t)
% X'(t)= I_n kron [1 y(t-1)' ...y(t-p)']


% Generate lagged Y matrix. This will be part of the X matrix
ylag = mlag2(Y,p); % Y is [T x M]. ylag is [T x (Mp)]
% Form RHS matrix X_t = [1 y_t-1 y_t-2 ... y_t-k] for t=1:T
ylag = ylag(p+tau+1:t,:);

K = n + p*(n^2); % K is the number of elements in the state vector
% Create X'(t) matrix.
X = zeros((t-tau-p)*n,K);
for i = 1:t-tau-p
    ztemp = eye(n);
    for j = 1:p        
        xtemp = ylag(i,(j-1)*n+1:j*n);
        xtemp = kron(eye(n),xtemp);
        ztemp = [ztemp xtemp];  %#ok<AGROW>
    end
    X((i-1)*n+1:i*n,:) = ztemp;
end 



% Redefine FAVAR variables y
y = Y(tau+p+1:t,:)';
DateLabels=DateLabels(tau+p+1:t,:);
% Time series observations
t=size(y,2);   % t is now 215 - p - tau = 173
startDate = datenum(DateLabels(1));
endDate = datenum(DateLabels(end));
xData = linspace(startDate,endDate,length(y'));
