%%
% <BetaDiagnostics.html> 