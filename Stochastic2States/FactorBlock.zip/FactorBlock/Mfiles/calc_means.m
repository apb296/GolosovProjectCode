%----------------------------SAVE AFTER-BURN-IN DRAWS AND IMPULSE RESPONSES -----------------

   % Print iterations
    if mod(irep,it_print) == 0
        disp(irep);toc;
    end 
% Calculate the recursive means
% Bt_rec_mean(irep,:,:)= (Bt_rec_mean(irep-1)*(irep-1)+Btdraw(:,rand_t))/irep;
% At_rec_mean(irep,:,:)= (At_rec_mean(irep-1)*(irep-1)+Atdraw(:,rand_t))/irep;
% Sigt_rec_mean(irep,:,:)= (Sigt_rec_mean(irep-1)*(irep-1)+Sigtdraw(:,rand_t))/irep;
% 
% Q_rec_mean(irep,:,:)= (Q_rec_mean(irep-1)*(irep-1)+Qdraw)/irep;
% %S_rec_mean(irep,:,:)= (S_rec_mean(irep-1)*(irep-1)+Sdraw)/irep;
% W_rec_mean(irep,:,:)= (W_rec_mean(irep-1)*(irep-1)+Wdraw)/irep;

if irep > nburn;               

        Bt_postmean = Bt_postmean + Btdraw;   % regression coefficients B(t)
        At_postmean = At_postmean + Atdraw;   % lower triangular matrix A(t)
        Sigt_postmean = Sigt_postmean + Sigtdraw;  % diagonal std matrix SIGMA(t)
        Qmean = Qmean + Qdraw;     % covariance matrix Q of B(t)
        ikc = 1;
        for kk = 2:n
            Sdraw(((kk-1)+(kk-3)*(kk-2)/2):ikc,((kk-1)+(kk-3)*(kk-2)/2):ikc)=Sblockdraw{kk-1};
            ikc = ikc + kk;
        end
        Smean = Smean + Sdraw;    % covariance matrix S of A(t)
        Wmean = Wmean + Wdraw;    % covariance matrix W of SIGMA(t)
        % Get time-varying correlations and variances
        stemp6 = zeros(n,1);
        stemp5 = [];
        stemp7 = [];
        for i = 1:t
            stemp8 = corrvc(Ht((i-1)*n+1:i*n,:));
            stemp7a = [];
            ic = 1;
            for j = 1:n
                if j>1;
                    stemp7a = [stemp7a ; stemp8(j,1:ic)']; %#ok<AGROW>
                    ic = ic+1;
                end
                stemp6(j,1) = sqrt(Ht((i-1)*n+j,j));
            end
            stemp5 = [stemp5 ; stemp6']; %#ok<AGROW>
            stemp7 = [stemp7 ; stemp7a']; %#ok<AGROW>
        end
        sigmean = sigmean + stemp5; % diagonal of the VAR covariance matrix
        cormean =cormean + stemp7;  % off-diagonal elements of the VAR cov matrix
        sig2mo = sig2mo + stemp5.^2;
        cor2mo = cor2mo + stemp7.^2;
if mod(irep-nburn,KTh)==0 
        store_draws;
end
%[diag(Sdraw) ;diag(Wdraw)]
%Wdraw
end % END saving after burn-in results 
          