
    
    if (ctr<BatchSize) && (irep<nrep+nburn)
    
stSigtdraw(ctr,:,:)=Sigtdraw;
stAtdraw(ctr,:,:)=Atdraw;
stWdraw(ctr,:)=diag(Wdraw);
stSdraw(ctr,:)=diag(Sdraw);
stQdraw(ctr,:)=diag(Qdraw);
stBtdraw(ctr,:,:)=Btdraw;
ctr=ctr+1;
    else
stSigtdraw(ctr,:,:)=Sigtdraw;
stAtdraw(ctr,:,:)=Atdraw;
stWdraw(ctr,:)=diag(Wdraw);
stSdraw(ctr,:)=diag(Sdraw);
stQdraw(ctr,:)=diag(Qdraw);
stBtdraw(ctr,:,:)=Btdraw;

        filename =[SaveDataPath  'BatchNo' num2str(BatchNo) '.mat'];
 
        ['I am storing data upto iteration No ' num2str(irep) ' as Batch No' num2str(BatchNo) ]

    save(filename);
       clear ('stSigtdraw', 'stAtdraw', 'stBtdraw','stWdraw','stSdraw','stQdraw');
       %reset the counter
       ctr=1;
       %change the batch no
        BatchNo=BatchNo+1;
    end




