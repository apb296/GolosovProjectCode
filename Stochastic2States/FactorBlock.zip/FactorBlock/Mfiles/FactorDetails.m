%%



X_headers = [X_real_headers X_credit_headers X_prices_headers];
%%
figure(1)
subplot(2,2,1)

bar (Eigen_real.^2/sum(Eigen_real.^2));
title('Real')
subplot(2,2,2)

bar (Eigen_credit.^2/sum(Eigen_credit.^2), 'DisplayName', 'Eigen_real', 'YDataSource', 'Eigen_real'); figure(gcf)
title('Credit')

subplot(2,2,3)
bar (Eigen_prices.^2/sum(Eigen_prices.^2), 'DisplayName', 'Eigen_real', 'YDataSource', 'Eigen_real'); figure(gcf)
title('Prices')
%%

figure (2)

plot(Loadings_real(:,1))
set(gca,'XTickLabel',X_real_headers(1,2:end))
title('Real')
%%
figure(3)
plot(Loadings_credit(:,1))
set(gca,'XTickLabel',X_credit_headers(1,2:end))
title('Credit')
%%
figure(4)
plot(Loadings_prices(:,1))
set(gca,'XTickLabel',X_prices_headers(1,2:end))
title('Prices')
%%