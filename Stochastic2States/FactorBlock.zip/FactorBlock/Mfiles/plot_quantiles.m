function plot_quantiles (data,sigma)
N=size(data,1);
m=size(data,2);
t=size(data,3);
tr=0

    for i_m=1:m

quant_data=quantile(data(:,i_m,:),[.05 .5 .95]);
subplot(m,1,i_m);
plot([log(sigma(i_m,tr+1:end))' squeeze(quant_data(:,1,:))']);
    end
    