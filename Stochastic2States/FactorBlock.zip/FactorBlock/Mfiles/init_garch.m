function [Btdraw,Atdraw ,Sigtdraw,Sblockdraw,Wdraw,Qdraw]  = init_garch(y_data,n,p)
K = n + p*(n^2)
Sblockdraw = cell(n-1,1); 
t=length(y_data);

tau=t-2;

[B_OLS,VB_OLS,A_OLS,sigma_OLS,VA_OLS]= ts_prior(y_data,tau,n,p);
B_0=[B_OLS(1:n)]';
B_1=reshape(B_OLS(n+1:end),n,n);
for i=2:t
res(i,:)=y_data(i,:)'-B_0'-B_1*y_data(i-1,:)';
end
[parameters, loglikelihood, Ht, likelihoods, stdresid, stderrors, A, B, scores]  = dcc_mvgarch(res,1,1,1,1);



Omega=Ht;

for ii=1:t
    
achol = chol(Omega(:,:,ii))';
% cholesky of Omega(t)
ssig = zeros(n,n);
for i = 1:n
    ssig(i,i) = achol(i,i); 
    for j = 1:n
        achol(j,i) = achol(j,i)/ssig(i,i);
    end
end
%normalizing cholesky of Omega(t) so that diagonal is unity
achol = inv(achol);
numa = n*(n-1)/2;
a0 = zeros(numa,1);
ic = 1;
for i = 2:n
    for j = 1:i-1
        a0(ic,1) = achol(i,j);
        ic = ic + 1;
    end
end
ssig1 = zeros(n,1);
for i = 1:n
    ssig1(i,1) = log(ssig(i,i)^2);
end

Atdraw(:,ii)=a0;
Sigtdraw(:,ii)=ssig1;

Btdraw(:,ii)=B_OLS;









end
   %=====| Draw S, the covariance of A(t) (from iWishart)
    % Take the SSE in the state equation of A(t)
    
 Attemp = Atdraw(:,2:t)' - Atdraw(:,1:t-1)';
    sse_2 = zeros(numa,numa);
    for i = 1:t-1
        sse_2 = sse_2 + Attemp(i,:)'*Attemp(i,:);
    end

    % ...and subsequently draw S, the covariance matrix of A(t)
    ijc = 1;
    for jj=2:n
        Sinv = inv(sse_2(((jj-1)+(jj-3)*(jj-2)/2):ijc,((jj-1)+(jj-3)*(jj-2)/2):ijc));
        Sinvblockdraw = wish(Sinv,t);
        Sblockdraw{jj-1} = inv(Sinvblockdraw); % this is a draw from S
        ijc = ijc + jj;
    end





    %=====| Draw W, the covariance of SIGMA(t) (from iWishart)
    % Get first differences of Sigtdraw to compute the SSE
Sigttemp = Sigtdraw(:,2:t)' - Sigtdraw(:,1:t-1)';

    sse_2 = zeros(n,n);
    for i = 1:t-1
        sse_2 = sse_2 + Sigttemp(i,:)'*Sigttemp(i,:);
    end
    Winv = inv(sse_2);
    Winvdraw = wish(Winv,t);
    Wdraw = inv(Winvdraw);  % this is a draw from W
    
    
    
    %=====| Draw Q, the covariance of B(t) (from iWishart)
    % Take the SSE in the state equation of B(t)
    Btemp = Btdraw(:,2:t)' - Btdraw(:,1:t-1)';
    sse_2 = zeros(K,K);
    for i = 1:t-1
        sse_2 = sse_2 + Btemp(i,:)'*Btemp(i,:);
    end
    
    % ...and subsequently draw Q, the covariance matrix of B(t)
    Qinv = inv(sse_2+.001);
    Qinvdraw = wish(Qinv,t);
    Qdraw = 0*eye(K);  % this is a draw from Q
    
    