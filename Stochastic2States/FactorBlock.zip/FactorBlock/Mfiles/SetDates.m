
fr=12*4
set(gca,'XTick',xData(1:fr:t))
datetick(gca,'x','yyyy','keepticks')
xticklabel_rotate([],45)
