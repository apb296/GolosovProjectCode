
yy=yhat(2,:);
ZZt=-yhat(1,:)';
HHt=sigmatemp;
QQt=Sblockdraw{1};
mm=1;
pp=1;
tt=t;
BB0=A_0_prmean(1);
VV0=A_0_prvar(1,1);

[Atblockdraw,ll]=carter_kohn(yy,ZZt,HHt,QQt,mm,pp,tt,BB0,VV0);