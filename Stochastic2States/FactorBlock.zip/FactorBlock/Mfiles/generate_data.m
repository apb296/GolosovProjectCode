% This scripts generates data to test the adaptation of primeceri's code
function [y beta alpha sigma_tr S W Q]=generate_data(consQ,consS,consW)
clc
%paramters
n=3;
t=200;
p=1;
m=n+n^2*p;
numa=n*(n-1)/2;


%variables
beta=zeros(m,t);
alpha=zeros(numa,t);
sigma_tr=ones(n,t);
y=zeros(n,t);


beta(:,1)=[.01 .01 .01 .9 0 0 0 .9 0 0 0 .9]';
sigma_tr(:,1)=.1*ones(n,1);
B_c=beta(1:n,1);
alpha(:,1)=[.4;.01;.3];
B_p=reshape(beta(n+1:end,1),n,n);
y_ss=inv(eye(n)-B_p)*B_c;
y(:,1)=mvnrnd(y_ss,diag(sigma_tr(:,1)),1);

W=consW*eye(n,n);
Q=consQ*eye(m,m);
%S=consS*[1 0 0; 0 2 0; 0 0 3];
S=consS*eye(numa);

for i=2:t
    beta(:,i)=mvnrnd(beta(:,i-1),Q,1);
    alpha(:,i)=mvnrnd(alpha(:,i-1),S,1);
    sigma_tr(:,i)=exp(.5*mvnrnd(log(sigma_tr(:,i-1).^2),W,1));
    x=[eye(n) kron(eye(n),y(:,i-1)')];
    ctr=1;
    for r=1:n
        for c=1:n
            if r==c
                capA(r,c)=1;
            elseif r<c
                capA(r,c)=0;
            elseif r>c
                capA(r,c)=alpha(ctr,i);
                ctr=ctr+1;
            end
        end
    end

        capSig=diag(sigma_tr(:,i));
        Omega=inv(capA)*(capSig*capSig)*inv(capA');
        y(:,i)=mvnrnd(x*beta(:,i),Omega,1);
     
         
end
y=y(:,2:end);
%pause





    
    
    
    



