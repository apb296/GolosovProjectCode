    % First create capAt, the lower-triangular matrix A(t) with ones on the
    % main diagonal. This is because the vector Atdraw has a draw of only the
    % non-zero and non-one elements of A(t) only.
    capAt = zeros(n*t,n);
    for i = 1:t
        capatemp = eye(n);
        aatemp = Atdraw(:,i);
        ic=1;
        for j = 2:n
            capatemp(j,1:j-1) = aatemp(ic:ic+j-2,1)';
            ic = ic + j - 1;
        end
        capAt((i-1)*n+1:i*n,:) = capatemp;
    end
    
    % yhat is the vector y(t) - Z x B(t) defined previously. Multiply yhat
    % with capAt, i.e the lower triangular matrix A(t). Then take squares
    % of the resulting quantity (saved in matrix y2)
    y2 = [];
    for i = 1:t
        ytemps = capAt((i-1)*n+1:i*n,:)*yhat(:,i);
        y2 = [y2  (ytemps.^2)]; %#ok<AGROW>
    end   

    % Transform to the log-scale but also add the 'offset constant' to prevent
    % the case where y2 is zero (in this case, its log would be -Infinity) 
    yss = zeros(t,n);
    for i = 1:n
        yss(:,i) = log(y2(i,:)' + 0.001);
    end
    
    % In order to draw the log-volatilies, substract the mean and variance
    % of the 7-component mixture of Normal approximation to the measurement
    % error covariance
    vart = zeros(t*n,n);
    yss1 = zeros(t,n);
    for i = 1:t
        for j = 1:n
            imix = statedraw(i,j);
            vart((i-1)*n+j,j) = u2_s(imix);
            yss1(i,j) = yss(i,j) - m_s(imix) + 1.2704;
        end
    end
    
    % Sigtdraw is a draw of the diagonal log-volatilies, which will give us SIGMA(t)
    [Sigtdraw,log_lik3] = carter_kohn(yss1',Zs,vart,Wdraw,n,n,t,sigma_prmean,sigma_prvar);
    
    % Next draw statedraw (chi square approximation mixture component) conditional on Sigtdraw
    % This is used to update at the next step the log-volatilities Sigtdraw
    for jj = 1:n
        for i = 1:t
            for j = 1:numel(m_s)
                temp1= (1/sqrt(2*pi*u2_s(j)))*exp(-.5*(((yss(i,jj) - Sigtdraw(jj,i) - m_s(j) + 1.2704)^2)/u2_s(j)));
                prw(j,1) = q_s(j,1)*temp1;
            end
            prw = prw./sum(prw);
            cprw = cumsum(prw);
            trand = rand(1,1);
            if trand < cprw(1,1); imix=1;
            elseif trand < cprw(2,1), imix=2;
            elseif trand < cprw(3,1), imix=3;
            elseif trand < cprw(4,1), imix=4;
            elseif trand < cprw(5,1), imix=5;
            elseif trand < cprw(6,1), imix=6;
            else imix=7; 
            end
            statedraw(i,jj)=imix;  % this is a draw of the mixture component index
        end
    end
    
    % Draws in Sigtdraw are in logarithmic scale (log-volatilies). Create 
    % original standard deviations of the VAR covariance matrix
    sigtemp = eye(n);
    sigt = zeros(n*t,n);
    for i = 1:t
        for j = 1:n
            sigtemp(j,j) = exp(0.5*Sigtdraw(j,i));
        end
        sigt((i-1)*n+1:i*n,:) = sigtemp;
    end

    %=====| Draw W, the covariance of SIGMA(t) (from iWishart)
    % Get first differences of Sigtdraw to compute the SSE
    Sigttemp = Sigtdraw(:,2:t)' - Sigtdraw(:,1:t-1)';

%     sse_2 = zeros(n,n);
%     for i = 1:t-1
%         sse_2 = sse_2 + Sigttemp(i,:)'*Sigttemp(i,:);
%     end
   Winv = inv((t-2)*cov(diff(Sigtdraw,1,2)') + W_prmean);
%  Winv = inv((t-2)*cov(diff(log(sigma_tr.^2),1,2)') + W_prmean);
Winvdraw = wish(Winv,t+W_prvar);
    Wdraw = inv(Winvdraw);  % this is a draw from W
    % Create the VAR covariance matrix H(t). It holds that:
    %           A(t) x H(t) x A(t)' = SIGMA(t) x SIGMA(t) '
    Ht = zeros(n*t,n);
    Htsd = zeros(n*t,n);
    for i = 1:t
        inva = inv(capAt((i-1)*n+1:i*n,:));
        stem = sigt((i-1)*n+1:i*n,:);
        Hsd = inva*stem;
        Hdraw = Hsd*Hsd';
        Ht((i-1)*n+1:i*n,:) = Hdraw;  % H(t)
        Htsd((i-1)*n+1:i*n,:) = Hsd;  % Cholesky of H(t)
    end
    
    