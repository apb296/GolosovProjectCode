% Number of replications
nrep = 250000;  
%%
% Number of burn-in-draws
nburn = 5000;   
%%
% Print in the screen every "it_print"-th iteration
it_print =10000;  

% Thining factor : KTh..this instructs the sampler to store every Kth draw.
% This will thin the chain but tell us more complete story of whats going
% on thru the sampling
KTh=5;
% Number of draws to store for obtaining the quantiles
stdraws=nrep/KTh;

% Size of the batch of draws to write on the disk 
BatchSize=stdraws/5;


% Storage matrices for posteriors and stuff
Bt_postmean = zeros(K,t);    % regression coefficients B(t)
At_postmean = zeros(numa,t); % lower triangular matrix A(t)
Sigt_postmean = zeros(n,t);  % diagonal std matrix SIGMA(t)
Qmean = zeros(K,K);          % covariance matrix Q of B(t)
Smean = zeros(numa,numa);    % covariance matrix S of A(t)
Wmean = zeros(n,n);          % covariance matrix W of SIGMA(t)

sigmean = zeros(t,n);    % mean of the diagonal of the VAR covariance matrix
cormean = zeros(t,numa); % mean of the off-diagonal elements of the VAR cov matrix
sig2mo = zeros(t,n);     % squares of the diagonal of the VAR covariance matrix
cor2mo = zeros(t,numa);  % squares of the off-diagonal elements of the VAR cov matrix

stSigtdraw=zeros(BatchSize,n,t);
stAtdraw=zeros(BatchSize,numa,t);
stWdraw=zeros(BatchSize,n);
stSdraw=zeros(BatchSize,numa);
stBtdraw=zeros(BatchSize,K,t);
stQdraw=zeros(BatchSize,K);

ctr=1;
BatchNo=1;




%====================================== START SAMPLING ========================================
%==============================================================================================
tic; % This is just a timer
disp('Number of iterations');

